"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Fingerprint } from "lucide-react"
import usePOSStore from "@/lib/store/pos-store"
import { getDBService } from "@/lib/db/db-service"
import BiometricAuth from "@/components/biometric-auth"

export default function LoginPage() {
  const router = useRouter()
  const [pin, setPin] = useState("")
  const [selectedStore, setSelectedStore] = useState("")
  const [stores, setStores] = useState<{ id: string; name: string }[]>([])
  const [error, setError] = useState<string | null>(null)
  const [showBiometric, setShowBiometric] = useState(false)

  const { loginWithPIN, loginWithBiometric, isAuthenticated } = usePOSStore()

  // Cargar tiendas al iniciar
  useEffect(() => {
    const loadStores = async () => {
      const db = getDBService()
      const storesList = await db.getStores()
      setStores(storesList.map((store) => ({ id: store.id, name: store.name })))

      if (storesList.length > 0) {
        setSelectedStore(storesList[0].id)
      }
    }

    loadStores()
  }, [])

  // Redirigir si ya está autenticado
  useEffect(() => {
    if (isAuthenticated) {
      router.push("/pos")
    }
  }, [isAuthenticated, router])

  const handlePinInput = (digit: string) => {
    if (pin.length < 4) {
      setPin((prev) => prev + digit)
    }
  }

  const handleBackspace = () => {
    setPin((prev) => prev.slice(0, -1))
  }

  const handleClear = () => {
    setPin("")
  }

  const handleLogin = async () => {
    if (pin.length !== 4 || !selectedStore) {
      setError("Ingrese un PIN de 4 dígitos y seleccione una tienda")
      return
    }

    const success = await loginWithPIN(pin, selectedStore)

    if (success) {
      router.push("/pos")
    } else {
      setError("PIN inválido o usuario no encontrado")
      setPin("")
    }
  }

  const handleBiometricSuccess = async (employeeId: string) => {
    // En una implementación real, aquí se obtendría el empleado y se iniciaría sesión
    const success = await loginWithBiometric("fingerprint")

    if (success) {
      router.push("/pos")
    } else {
      setError("Error en autenticación biométrica")
      setShowBiometric(false)
    }
  }

  const handleBiometricError = (errorMsg: string) => {
    setError(errorMsg)
    setShowBiometric(false)
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
          {showBiometric ? (
            <BiometricAuth
              onSuccess={handleBiometricSuccess}
              onError={handleBiometricError}
              onCancel={() => setShowBiometric(false)}
            />
          ) : (
            <>
              <div className="text-center mb-6">
                <div className="flex justify-center mb-4">
                  <Image
                    src="/burger-king-logo.png"
                    alt="Burger King Logo"
                    width={80}
                    height={80}
                    className="object-contain"
                  />
                </div>
                <h1 className="text-2xl font-bold text-red-600">Burger King POS</h1>
                <p className="text-gray-600">Ingrese su PIN para continuar</p>
              </div>

              {error && (
                <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">{error}</div>
              )}

              <div className="mb-4">
                <label htmlFor="store" className="block text-sm font-medium text-gray-700 mb-1">
                  Seleccione Sucursal
                </label>
                <select
                  id="store"
                  value={selectedStore}
                  onChange={(e) => setSelectedStore(e.target.value)}
                  className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                >
                  <option value="">Seleccione una sucursal</option>
                  {stores.map((store) => (
                    <option key={store.id} value={store.id}>
                      {store.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="mb-6">
                <label htmlFor="pin" className="block text-sm font-medium text-gray-700 mb-1">
                  PIN
                </label>
                <input
                  type="password"
                  id="pin"
                  value={pin}
                  readOnly
                  className="w-full p-2 text-center text-2xl tracking-widest border rounded-lg"
                  placeholder="••••"
                />
              </div>

              <div className="grid grid-cols-3 gap-2 mb-4">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((digit) => (
                  <button
                    key={digit}
                    onClick={() => handlePinInput(digit.toString())}
                    className="p-4 text-xl font-bold bg-gray-100 rounded-lg hover:bg-gray-200"
                  >
                    {digit}
                  </button>
                ))}
                <button
                  onClick={handleClear}
                  className="p-4 text-sm font-medium bg-gray-200 rounded-lg hover:bg-gray-300"
                >
                  Limpiar
                </button>
                <button
                  onClick={() => handlePinInput("0")}
                  className="p-4 text-xl font-bold bg-gray-100 rounded-lg hover:bg-gray-200"
                >
                  0
                </button>
                <button
                  onClick={handleBackspace}
                  className="p-4 text-sm font-medium bg-gray-200 rounded-lg hover:bg-gray-300"
                >
                  Borrar
                </button>
              </div>

              <div className="space-y-2">
                <button
                  onClick={handleLogin}
                  className="w-full py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 font-medium"
                  disabled={pin.length !== 4 || !selectedStore}
                >
                  Ingresar
                </button>

                <button
                  onClick={() => setShowBiometric(true)}
                  className="w-full py-3 flex items-center justify-center bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
                >
                  <Fingerprint size={20} className="mr-2" />
                  Usar Biometría
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      <footer className="bg-white p-4 text-center text-gray-600 text-sm">
        &copy; {new Date().getFullYear()} Burger King. Todos los derechos reservados.
      </footer>
    </div>
  )
}
