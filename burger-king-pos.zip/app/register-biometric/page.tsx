"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Fingerprint, Camera, Check, X } from "lucide-react"
import { getDBService } from "@/lib/db/db-service"
import { getBiometricService } from "@/lib/services/biometric-service"
import type { Employee } from "@/lib/types/pos"

export default function RegisterBiometricPage() {
  const router = useRouter()
  const [employees, setEmployees] = useState<Employee[]>([])
  const [selectedEmployee, setSelectedEmployee] = useState<string>("")
  const [biometricType, setBiometricType] = useState<"fingerprint" | "facialRecognition">("fingerprint")
  const [step, setStep] = useState<"select-employee" | "select-type" | "capture" | "success" | "error">(
    "select-employee",
  )
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Cargar empleados
  useEffect(() => {
    const loadEmployees = async () => {
      const db = getDBService()
      const employeesList = await db.getEmployees()
      setEmployees(employeesList)
    }

    loadEmployees()
  }, [])

  const handleEmployeeSelect = (employeeId: string) => {
    setSelectedEmployee(employeeId)
    setStep("select-type")
  }

  const handleTypeSelect = (type: "fingerprint" | "facialRecognition") => {
    setBiometricType(type)
    setStep("capture")
  }

  const handleCapture = async () => {
    if (!selectedEmployee) return

    setIsLoading(true)
    setError(null)

    try {
      const bioService = getBiometricService()

      // Capturar datos biométricos
      let biometricTemplate = ""
      if (biometricType === "fingerprint") {
        biometricTemplate = await bioService.captureFingerprint()
      } else {
        biometricTemplate = await bioService.captureFacialRecognition()
      }

      // Registrar los datos biométricos
      const success = await bioService.registerBiometric(selectedEmployee, biometricType, biometricTemplate)

      if (success) {
        setStep("success")
      } else {
        throw new Error("No se pudo registrar los datos biométricos")
      }
    } catch (error) {
      console.error("Error registering biometric:", error)
      setError("Error al registrar datos biométricos")
      setStep("error")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <header className="bg-red-600 text-white p-4">
        <div className="container mx-auto flex items-center">
          <Image src="/burger-king-logo.png" alt="Burger King Logo" width={40} height={40} className="mr-2" />
          <h1 className="text-xl font-bold">Registro Biométrico</h1>
        </div>
      </header>

      <main className="flex-1 container mx-auto p-4 flex items-center justify-center">
        <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
          {step === "select-employee" && (
            <>
              <h2 className="text-xl font-bold mb-4 text-center">Seleccionar Empleado</h2>

              {employees.length === 0 ? (
                <p className="text-center text-gray-500">Cargando empleados...</p>
              ) : (
                <div className="space-y-2 max-h-80 overflow-y-auto">
                  {employees.map((employee) => (
                    <button
                      key={employee.id}
                      onClick={() => handleEmployeeSelect(employee.id)}
                      className="w-full p-3 text-left border rounded-lg hover:bg-gray-50 flex justify-between items-center"
                    >
                      <div>
                        <p className="font-medium">{employee.name}</p>
                        <p className="text-sm text-gray-500">{employee.role}</p>
                      </div>
                      {employee.biometricId && (
                        <span className="text-green-500">
                          <Check size={20} />
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              )}

              <button
                onClick={() => router.push("/admin")}
                className="w-full mt-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
              >
                Volver
              </button>
            </>
          )}

          {step === "select-type" && (
            <>
              <h2 className="text-xl font-bold mb-4 text-center">Seleccionar Tipo de Biometría</h2>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <button
                  onClick={() => handleTypeSelect("fingerprint")}
                  className="flex flex-col items-center justify-center p-4 border rounded-lg hover:bg-gray-50"
                >
                  <Fingerprint size={48} className="text-red-600 mb-2" />
                  <span>Huella Digital</span>
                </button>

                <button
                  onClick={() => handleTypeSelect("facialRecognition")}
                  className="flex flex-col items-center justify-center p-4 border rounded-lg hover:bg-gray-50"
                >
                  <Camera size={48} className="text-red-600 mb-2" />
                  <span>Reconocimiento Facial</span>
                </button>
              </div>

              <button
                onClick={() => setStep("select-employee")}
                className="w-full py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
              >
                Atrás
              </button>
            </>
          )}

          {step === "capture" && (
            <>
              <h2 className="text-xl font-bold mb-4 text-center">
                {biometricType === "fingerprint" ? "Capturar Huella Digital" : "Capturar Reconocimiento Facial"}
              </h2>

              <div className="flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-lg mb-6">
                {isLoading ? (
                  <div className="text-center">
                    <div className="w-16 h-16 border-4 border-red-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                    <p>
                      {biometricType === "fingerprint"
                        ? "Procesando huella digital..."
                        : "Procesando reconocimiento facial..."}
                    </p>
                  </div>
                ) : (
                  <>
                    {biometricType === "fingerprint" ? (
                      <>
                        <Fingerprint size={64} className="text-red-600 mb-4" />
                        <p className="text-center">Coloque su dedo en el lector de huellas</p>
                      </>
                    ) : (
                      <>
                        <Camera size={64} className="text-red-600 mb-4" />
                        <p className="text-center">Mire a la cámara para reconocimiento facial</p>
                      </>
                    )}
                  </>
                )}
              </div>

              <div className="flex space-x-2">
                <button
                  onClick={() => setStep("select-type")}
                  className="flex-1 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
                  disabled={isLoading}
                >
                  Atrás
                </button>
                <button
                  onClick={handleCapture}
                  className="flex-1 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                  disabled={isLoading}
                >
                  Capturar
                </button>
              </div>
            </>
          )}

          {step === "success" && (
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check size={32} className="text-green-600" />
              </div>
              <h2 className="text-xl font-bold mb-2">¡Registro Exitoso!</h2>
              <p className="mb-6">Los datos biométricos se han registrado correctamente.</p>
              <button
                onClick={() => router.push("/admin")}
                className="w-full py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                Volver al Panel de Administración
              </button>
            </div>
          )}

          {step === "error" && (
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <X size={32} className="text-red-600" />
              </div>
              <h2 className="text-xl font-bold mb-2">Error</h2>
              <p className="mb-6">{error || "Ocurrió un error durante el registro biométrico."}</p>
              <button
                onClick={() => setStep("select-employee")}
                className="w-full py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
              >
                Intentar Nuevamente
              </button>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
