"use client"

import { useRef } from "react"

import { useState } from "react"

import type React from "react"
import { useEffect } from "react"
import { useRouter } from "next/navigation"
import usePOSStore from "@/lib/store/pos-store"
import CategoryPanel from "@/components/category-panel"
import ProductButton from "@/components/product-button"
import OrderSummary from "@/components/order-summary"
import type { Product, TimeOfDay } from "@/lib/types/pos"

export default function HomePage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [selectedCategory, setSelectedCategory] = useState<number>(1)
  const [timeOfDay, setTimeOfDay] = useState<TimeOfDay>("morning")
  const timerRef = useRef<NodeJS.Timeout | null>(null)
  const {
    isAuthenticated,
    currentUser,
    currentEmployeeId,
    currentStoreId,
    products,
    categories,
    currentOrder,
    createOrder,
    addItemToOrder,
    removeItemFromOrder,
    updateItemQuantity,
    completeOrder,
    cancelOrder,
    openCashRegister,
    closeCashRegister,
    cashRegisters,
  } = usePOSStore()

  useEffect(() => {
    // Redirigir según el estado de autenticación
    if (isAuthenticated) {
      router.push("/pos")
    } else {
      router.push("/login")
    }
  }, [isAuthenticated, router])

  useEffect(() => {
    // Set a small delay to ensure store is loaded
    timerRef.current = setTimeout(() => setIsLoading(false), 500) as NodeJS.Timeout

    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current)
      }
    }
  }, [])

  // Update time of day
  useEffect(() => {
    const updateTimeOfDay = () => {
      const hour = new Date().getHours()
      if (hour >= 5 && hour < 12) {
        setTimeOfDay("morning")
      } else if (hour >= 12 && hour < 18) {
        setTimeOfDay("afternoon")
      } else {
        setTimeOfDay("night")
      }
    }

    updateTimeOfDay()
    const interval = setInterval(updateTimeOfDay, 60000) as NodeJS.Timeout

    return () => clearInterval(interval)
  }, [])

  // Create a new order if none exists
  useEffect(() => {
    if (!currentOrder && currentEmployeeId && currentStoreId) {
      createOrder()
    }
  }, [currentOrder, currentEmployeeId, currentStoreId, createOrder])

  // Sample products data
  const productsByCategory: Record<number, Product[]> = {
    1: [
      {
        id: 101,
        name: "Whopper",
        price: 89.9,
        image: "/products/whopper.jpg",
        categoryId: 1,
        currentStock: 50,
        status: "active",
      },
      {
        id: 102,
        name: "Whopper con Queso",
        price: 99.9,
        image: "/products/whopper-queso.jpg",
        categoryId: 1,
        currentStock: 50,
        status: "active",
      },
      {
        id: 103,
        name: "Hamburguesa Clásica",
        price: 59.9,
        image: "/products/hamburguesa-clasica.jpg",
        categoryId: 1,
        currentStock: 50,
        status: "active",
      },
      {
        id: 104,
        name: "Hamburguesa con Queso",
        price: 69.9,
        image: "/products/hamburguesa-queso.jpg",
        categoryId: 1,
        currentStock: 50,
        status: "active",
      },
      {
        id: 105,
        name: "Whopper Doble",
        price: 119.9,
        image: "/products/whopper-doble.jpg",
        categoryId: 1,
        currentStock: 50,
        status: "active",
      },
      {
        id: 106,
        name: "King de Pollo",
        price: 79.9,
        image: "/products/king-pollo.jpg",
        categoryId: 1,
        currentStock: 50,
        status: "active",
      },
    ],
    2: [
      {
        id: 201,
        name: "Papas Fritas Chicas",
        price: 29.9,
        image: "/products/papas-chicas.jpg",
        categoryId: 2,
        currentStock: 100,
        status: "active",
      },
      {
        id: 202,
        name: "Papas Fritas Medianas",
        price: 39.9,
        image: "/products/papas-medianas.jpg",
        categoryId: 2,
        currentStock: 100,
        status: "active",
      },
      {
        id: 203,
        name: "Papas Fritas Grandes",
        price: 49.9,
        image: "/products/papas-grandes.jpg",
        categoryId: 2,
        currentStock: 100,
        status: "active",
      },
      {
        id: 204,
        name: "Aros de Cebolla",
        price: 45.9,
        image: "/products/aros-cebolla.jpg",
        categoryId: 2,
        currentStock: 80,
        status: "active",
      },
      {
        id: 205,
        name: "Nuggets (6 pzs)",
        price: 59.9,
        image: "/products/nuggets.jpg",
        categoryId: 2,
        currentStock: 80,
        status: "active",
      },
    ],
    3: [
      {
        id: 301,
        name: "Refresco Chico",
        price: 25.9,
        image: "/products/refresco-chico.jpg",
        categoryId: 3,
        currentStock: 200,
        status: "active",
      },
      {
        id: 302,
        name: "Refresco Mediano",
        price: 35.9,
        image: "/products/refresco-mediano.jpg",
        categoryId: 3,
        currentStock: 200,
        status: "active",
      },
      {
        id: 303,
        name: "Refresco Grande",
        price: 45.9,
        image: "/products/refresco-grande.jpg",
        categoryId: 3,
        currentStock: 200,
        status: "active",
      },
      {
        id: 304,
        name: "Agua Mineral",
        price: 29.9,
        image: "/products/agua.jpg",
        categoryId: 3,
        currentStock: 150,
        status: "active",
      },
      {
        id: 305,
        name: "Café",
        price: 25.9,
        image: "/products/cafe.jpg",
        categoryId: 3,
        currentStock: 100,
        status: "active",
      },
    ],
    4: [
      {
        id: 401,
        name: "Sundae de Chocolate",
        price: 29.9,
        image: "/products/sundae-chocolate.jpg",
        categoryId: 4,
        currentStock: 50,
        status: "active",
      },
      {
        id: 402,
        name: "Sundae de Fresa",
        price: 29.9,
        image: "/products/sundae-fresa.jpg",
        categoryId: 4,
        currentStock: 50,
        status: "active",
      },
      {
        id: 403,
        name: "Pastel de Chocolate",
        price: 39.9,
        image: "/products/pastel-chocolate.jpg",
        categoryId: 4,
        currentStock: 30,
        status: "active",
      },
      {
        id: 404,
        name: "King Fusion Oreo",
        price: 45.9,
        image: "/products/king-fusion-oreo.jpg",
        categoryId: 4,
        currentStock: 40,
        status: "active",
      },
    ],
    5: [
      {
        id: 501,
        name: "Combo Whopper",
        price: 149.9,
        image: "/products/combo-whopper.jpg",
        categoryId: 5,
        currentStock: 50,
        status: "active",
      },
      {
        id: 502,
        name: "Combo King de Pollo",
        price: 139.9,
        image: "/products/combo-king-pollo.jpg",
        categoryId: 5,
        currentStock: 50,
        status: "active",
      },
      {
        id: 503,
        name: "Combo Familiar",
        price: 349.9,
        image: "/products/combo-familiar.jpg",
        categoryId: 5,
        currentStock: 30,
        status: "active",
      },
      {
        id: 504,
        name: "Combo Infantil",
        price: 119.9,
        image: "/products/combo-infantil.jpg",
        categoryId: 5,
        currentStock: 40,
        status: "active",
      },
    ],
  }

  // Handle category selection
  const handleCategoryClick = (categoryId: number) => {
    setSelectedCategory(categoryId)
  }

  // Handle product selection
  const handleProductClick = (product: Product) => {
    if (currentOrder) {
      addItemToOrder(product, 1)
    }
  }

  // Handle payment
  const handlePayment = (paymentMethod: string) => {
    if (currentOrder) {
      completeOrder(paymentMethod, currentOrder.total)
      // Show success message
      alert(`Orden completada. Método de pago: ${paymentMethod}`)
    }
  }

  // Handle cash register open
  const handleOpenCashRegister = (e: React.FormEvent) => {
    e.preventDefault()
    const form = e.target as HTMLFormElement
    const initialAmount = Number.parseFloat(form.initialAmount.value)

    if (isNaN(initialAmount) || initialAmount < 0) {
      alert("Por favor ingrese un monto válido")
      return
    }

    openCashRegister(currentStoreId || 0, currentEmployeeId || 0, initialAmount)
    document.getElementById("cash-register-dialog")?.classList.add("hidden")
  }

  // Handle cash register close
  const handleCloseCashRegister = (e: React.FormEvent) => {
    e.preventDefault()
    const form = e.target as HTMLFormElement
    const finalAmount = Number.parseFloat(form.finalAmount.value)

    if (isNaN(finalAmount) || finalAmount < 0) {
      alert("Por favor ingrese un monto válido")
      return
    }

    closeCashRegister(currentStoreId || 0, currentEmployeeId || 0, finalAmount)
    // Redirect to login after closing
    router.push("/login")
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-red-600 mx-auto mb-4"></div>
          <p className="text-xl font-medium">Cargando...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-red-600 text-white p-4">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center">
            <img src="/logo.png" alt="Burger King" className="h-10 mr-4" />
            <h1 className="text-xl font-bold">POS System</h1>
          </div>
          <div className="flex items-center">
            <span className="mr-4">
              {timeOfDay === "morning" && "¡Buenos días!"}
              {timeOfDay === "afternoon" && "¡Buenas tardes!"}
              {timeOfDay === "night" && "¡Buenas noches!"}
            </span>
            <span className="mr-4">{currentUser?.name || "Usuario"}</span>
            <button
              className="bg-white text-red-600 px-4 py-1 rounded-md hover:bg-red-100 transition-colors"
              onClick={() => document.getElementById("close-register-dialog")?.classList.remove("hidden")}
            >
              Cerrar Caja
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto p-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Left Column - Categories and Products */}
          <div className="md:col-span-2 space-y-4">
            {/* Categories */}
            <CategoryPanel
              categories={categories}
              selectedCategory={selectedCategory}
              onCategoryClick={handleCategoryClick}
            />

            {/* Products */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {productsByCategory[selectedCategory]?.map((product) => (
                <ProductButton
                  key={product.id}
                  product={product}
                  onClick={() => handleProductClick(product)}
                  disabled={product.currentStock <= 0}
                />
              ))}
            </div>
          </div>

          {/* Right Column - Order Summary */}
          <div className="bg-white p-4 rounded-lg shadow">
            <OrderSummary
              order={currentOrder}
              onRemoveItem={removeItemFromOrder}
              onUpdateQuantity={updateItemQuantity}
              onPayment={handlePayment}
              onCancel={cancelOrder}
            />
          </div>
        </div>
      </main>

      {/* Cash Register Open Dialog */}
      <div
        id="cash-register-dialog"
        className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden"
      >
        <div className="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
          <h2 className="text-xl font-bold mb-4">Abrir Caja</h2>
          <form onSubmit={handleOpenCashRegister}>
            <div className="mb-4">
              <label className="block text-gray-700 mb-2" htmlFor="initialAmount">
                Monto Inicial
              </label>
              <input
                type="number"
                id="initialAmount"
                name="initialAmount"
                className="w-full p-2 border rounded"
                step="0.01"
                min="0"
                required
              />
            </div>
            <div className="flex justify-end">
              <button
                type="submit"
                className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition-colors"
              >
                Abrir Caja
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Cash Register Close Dialog */}
      <div
        id="close-register-dialog"
        className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden"
      >
        <div className="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
          <h2 className="text-xl font-bold mb-4">Cerrar Caja</h2>
          <form onSubmit={handleCloseCashRegister}>
            <div className="mb-4">
              <label className="block text-gray-700 mb-2" htmlFor="finalAmount">
                Monto Final
              </label>
              <input
                type="number"
                id="finalAmount"
                name="finalAmount"
                className="w-full p-2 border rounded"
                step="0.01"
                min="0"
                required
              />
            </div>
            <div className="flex justify-between">
              <button
                type="button"
                className="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400 transition-colors"
                onClick={() => document.getElementById("close-register-dialog")?.classList.add("hidden")}
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition-colors"
              >
                Cerrar Caja
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
