"use client"

import { useEffect, useState, useRef } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Menu, Bell, LogOut, Package, BarChart4, Settings } from "lucide-react"
import usePOSStore from "@/lib/store/pos-store"
import CategoryPanel from "@/components/category-panel"
import ProductButton from "@/components/product-button"
import OrderSummary from "@/components/order-summary"
import CashRegisterModal from "@/components/cash-register-modal"
import TicketPreview from "@/components/ticket-preview"
import type { Product } from "@/lib/types/pos"

export default function POSPage() {
  const router = useRouter()
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>("")
  const [showCashRegisterModal, setShowCashRegisterModal] = useState(false)
  const [cashRegisterModalType, setCashRegisterModalType] = useState<"open" | "close">("open")
  const [showSidebar, setShowSidebar] = useState(false)
  const [showTicketPreview, setShowTicketPreview] = useState(false)
  const [completedOrder, setCompletedOrder] = useState<any>(null)

  // Referencia para imprimir
  const printTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  // Obtener estado del store
  const {
    currentUser,
    currentStore,
    isAuthenticated,
    currentOrder,
    currentOrderItems,
    currentCashRegister,
    categories,
    products,
    productsByCategory,
    inventory,
    isLoading,
    error,

    logout,
    createOrder,
    addItemToOrder,
    removeItemFromOrder,
    updateItemQuantity,
    completeOrder,
    cancelOrder,
    openCashRegister,
    closeCashRegister,

    fetchCategories,
    fetchProductsByCategory,
  } = usePOSStore()

  // Verificar autenticación
  useEffect(() => {
    if (!isAuthenticated || !currentUser) {
      router.push("/login")
    } else if (!currentCashRegister) {
      setShowCashRegisterModal(true)
      setCashRegisterModalType("open")
    } else if (!currentOrder) {
      createOrder()
    }
  }, [isAuthenticated, currentUser, currentCashRegister, currentOrder, router, createOrder])

  // Cargar categorías
  useEffect(() => {
    if (categories.length > 0 && !selectedCategoryId) {
      setSelectedCategoryId(categories[0]?.id || "")
    }
  }, [categories, selectedCategoryId])

  // Cargar productos cuando cambia la categoría
  useEffect(() => {
    if (selectedCategoryId && !productsByCategory[selectedCategoryId]) {
      fetchProductsByCategory(selectedCategoryId)
    }
  }, [selectedCategoryId, productsByCategory, fetchProductsByCategory])

  // Limpiar timeout al desmontar
  useEffect(() => {
    return () => {
      if (printTimeoutRef.current) {
        clearTimeout(printTimeoutRef.current)
      }
    }
  }, [])

  // Manejar selección de categoría
  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategoryId(categoryId)
  }

  // Manejar selección de producto
  const handleProductSelect = (product: Product) => {
    addItemToOrder(product, 1)
  }

  // Manejar apertura de caja
  const handleOpenCashRegister = async (amount: number) => {
    const success = await openCashRegister(amount)
    if (success) {
      setShowCashRegisterModal(false)
      createOrder()
    }
  }

  // Manejar cierre de caja
  const handleCloseCashRegister = async (amount: number) => {
    const success = await closeCashRegister(amount)
    if (success) {
      logout()
      router.push("/login")
    }
  }

  // Manejar envío del modal de caja
  const handleCashRegisterSubmit = (amount: number) => {
    if (cashRegisterModalType === "open") {
      handleOpenCashRegister(amount)
    } else {
      handleCloseCashRegister(amount)
    }
  }

  // Manejar botón de logout
  const handleLogoutClick = () => {
    if (currentCashRegister) {
      setShowCashRegisterModal(true)
      setCashRegisterModalType("close")
    } else {
      logout()
      router.push("/login")
    }
  }

  // Manejar completar orden
  const handleCompleteOrder = async (paymentMethod: "cash" | "card" | "mobile") => {
    // Guardar la orden actual para el ticket
    if (currentOrder && currentOrderItems.length > 0) {
      setCompletedOrder({
        order: { ...currentOrder, paymentMethod },
        items: [...currentOrderItems],
      })
    }

    const success = await completeOrder(paymentMethod)

    if (success) {
      // Mostrar vista previa del ticket
      setShowTicketPreview(true)

      // Ocultar automáticamente después de 10 segundos
      printTimeoutRef.current = setTimeout(() => {
        setShowTicketPreview(false)
        setCompletedOrder(null)
      }, 10000)
    }
  }

  // Manejar impresión de ticket
  const handlePrintTicket = () => {
    // En una implementación real, esto se conectaría con una impresora
    console.log("Imprimiendo ticket...", completedOrder)

    // Simular impresión
    window.print()

    // Cerrar vista previa
    setShowTicketPreview(false)
    setCompletedOrder(null)
  }

  // Obtener productos de la categoría seleccionada
  const currentCategoryProducts = selectedCategoryId ? productsByCategory[selectedCategoryId] || [] : []

  // Obtener inventario para un producto
  const getInventoryForProduct = (productId: string) => {
    return inventory.find((item) => item.productId === productId)
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-red-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-xl font-medium">Cargando...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-red-600 text-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <button onClick={() => setShowSidebar(!showSidebar)} className="mr-4 p-1 rounded-full hover:bg-red-700">
              <Menu size={24} />
            </button>
            <div className="flex items-center">
              <Image src="/burger-king-logo.png" alt="Burger King Logo" width={40} height={40} className="mr-2" />
              <div>
                <h1 className="font-bold text-lg">Burger King POS</h1>
                <p className="text-xs opacity-90">{currentStore?.name}</p>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <div className="text-right">
              <p className="font-medium">{currentUser?.name}</p>
              <p className="text-xs opacity-90">{currentUser?.role}</p>
            </div>
            <button onClick={handleLogoutClick} className="p-2 rounded-full hover:bg-red-700">
              <LogOut size={20} />
            </button>
          </div>
        </div>
      </header>

      {/* Sidebar */}
      {showSidebar && (
        <div className="fixed inset-0 z-50 flex">
          <div className="w-64 bg-white h-full shadow-lg">
            <div className="p-4 border-b">
              <div className="flex items-center">
                <Image
                  src="/burger-king-logo.png"
                  alt="Burger King Logo"
                  width={40}
                  height={40}
                  className="mr-2"
                />
                <h2 className="font-bold text-lg">Burger King</h2>
              </div>
            </div>

            <nav className="p-4">
              <ul className="space-y-2">
                <li>
                  <button className="flex items-center w-full p-2 rounded-lg hover:bg-gray-100">
                    <Package size={20} className="mr-3 text-red-600" />
                    <span>Solicitar Inventario</span>
                  </button>
                </li>
                <li>
                  <button className="flex items-center w-full p-2 rounded-lg hover:bg-gray-100">
                    <BarChart4 size={20} className="mr-3 text-red-600" />
                    <span>Reportes</span>
                  </button>
                </li>
                <li>
                  <button className="flex items-center w-full p-2 rounded-lg hover:bg-gray-100">
                    <Bell size={20} className="mr-3 text-red-600" />
                    <span>Notificaciones</span>
                  </button>
                </li>
                <li>
                  <button className="flex items-center w-full p-2 rounded-lg hover:bg-gray-100">
                    <Settings size={20} className="mr-3 text-red-600" />
                    <span>Configuración</span>
                  </button>
                </li>
              </ul>
            </nav>

            <div className="absolute bottom-0 w-full p-4 border-t">
              <button
                onClick={() => setShowSidebar(false)}
                className="w-full py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
              >
                Cerrar Menú
              </button>
            </div>
          </div>

          <div className="flex-1 bg-black bg-opacity-50" onClick={() => setShowSidebar(false)}></div>
        </div>
      )}

      {/* Main Content */}
      <main className="flex-1 flex overflow-hidden">
        {/* Products Section */}
        <div className="w-2/3 flex flex-col">
          <div className="p-4">
            <CategoryPanel
              categories={categories}
              selectedCategory={selectedCategoryId}
              onSelectCategory={handleCategorySelect}
            />
          </div>

          <div className="flex-1 overflow-y-auto p-4">
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {currentCategoryProducts.map((product) => (
                <ProductButton
                  key={product.id}
                  product={product}
                  inventory={getInventoryForProduct(product.id)}
                  onClick={handleProductSelect}
                  disabled={getInventoryForProduct(product.id)?.currentStock === 0}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Order Summary Section */}
        <div className="w-1/3 bg-white shadow-inner overflow-hidden flex flex-col">
          <div className="p-4 flex-1 overflow-y-auto">
            <OrderSummary
              order={currentOrder}
              orderItems={currentOrderItems}
              products={products}
              onRemoveItem={removeItemFromOrder}
              onUpdateQuantity={updateItemQuantity}
              onCompleteOrder={handleCompleteOrder}
              onCancelOrder={cancelOrder}
              onPrintTicket={() => setShowTicketPreview(true)}
            />
          </div>
        </div>
      </main>

      {/* Cash Register Modal */}
      {showCashRegisterModal && (
        <CashRegisterModal
          isOpen={showCashRegisterModal}
          type={cashRegisterModalType}
          onClose={() => {
            if (cashRegisterModalType === "open" && !currentCashRegister) {
              // No permitir cerrar el modal si es apertura de caja y no hay caja abierta
              return
            }
            setShowCashRegisterModal(false)
          }}
          onSubmit={handleCashRegisterSubmit}
        />
      )}

      {/* Ticket Preview Modal */}
      {showTicketPreview && completedOrder && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-lg p-6 max-w-md w-full">
            <TicketPreview
              order={completedOrder.order}
              orderItems={completedOrder.items}
              products={products}
              store={currentStore!}
              employee={currentUser!}
              onPrint={handlePrintTicket}
            />
            <div className="mt-4 flex justify-end">
              <button
                onClick={() => {
                  setShowTicketPreview(false)
                  setCompletedOrder(null)
                }}
                className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
