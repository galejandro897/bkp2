import { getDBService } from "../db/db-service"
import type { Employee, BiometricData } from "../types/pos"

class BiometricService {
  private db = getDBService()

  // Registrar datos biométricos para un empleado
  async registerBiometric(
    employeeId: string,
    biometricType: BiometricData["biometricType"],
    biometricTemplate: string,
  ): Promise<boolean> {
    try {
      // Verificar si el empleado existe
      const employee = await this.db.getEmployeeById(employeeId)
      if (!employee) {
        throw new Error("Empleado no encontrado")
      }

      // Verificar si ya tiene datos biométricos
      const existingBioData = await this.db.getBiometricDataByEmployeeId(employeeId)

      if (existingBioData) {
        // Actualizar datos existentes
        await this.db.updateBiometricData(employeeId, {
          biometricType,
          biometricTemplate,
        })
      } else {
        // Crear nuevos datos biométricos
        await this.db.createBiometricData({
          employeeId,
          biometricType,
          biometricTemplate,
        })
      }

      // Actualizar el empleado con el ID biométrico
      await this.db.updateEmployee(employeeId, {
        biometricId: employeeId, // Usamos el mismo ID para simplificar
      })

      return true
    } catch (error) {
      console.error("Error registering biometric data:", error)
      return false
    }
  }

  // Autenticar empleado mediante biometría
  async authenticateWithBiometric(biometricTemplate: string): Promise<Employee | null> {
    try {
      return await this.db.authenticateWithBiometric(biometricTemplate)
    } catch (error) {
      console.error("Error authenticating with biometric:", error)
      return null
    }
  }

  // Capturar huella digital (simulado)
  async captureFingerprint(): Promise<string> {
    // En una implementación real, esto se conectaría con un dispositivo de huellas
    // Para esta demo, generamos un template aleatorio
    return new Promise((resolve) => {
      setTimeout(() => {
        const randomTemplate = `fp_${Math.random().toString(36).substring(2, 15)}`
        resolve(randomTemplate)
      }, 1500) // Simulamos un retraso de 1.5 segundos para la captura
    })
  }

  // Capturar reconocimiento facial (simulado)
  async captureFacialRecognition(): Promise<string> {
    // En una implementación real, esto se conectaría con una cámara
    // Para esta demo, generamos un template aleatorio
    return new Promise((resolve) => {
      setTimeout(() => {
        const randomTemplate = `face_${Math.random().toString(36).substring(2, 15)}`
        resolve(randomTemplate)
      }, 2000) // Simulamos un retraso de 2 segundos para la captura
    })
  }

  // Verificar si un empleado tiene datos biométricos registrados
  async hasBiometricData(employeeId: string): Promise<boolean> {
    const bioData = await this.db.getBiometricDataByEmployeeId(employeeId)
    return bioData !== null
  }
}

// Crear una instancia singleton
let biometricService: BiometricService

export function getBiometricService(): BiometricService {
  if (typeof window !== "undefined" && !biometricService) {
    biometricService = new BiometricService()
  }
  return biometricService as BiometricService
}
