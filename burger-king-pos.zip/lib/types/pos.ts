export interface Employee {
  id: string
  name: string
  email: string
  role: "admin" | "manager" | "cashier" | "kitchen"
  pin: string
  biometricId?: string
  storeId: string
  status: "active" | "inactive"
  createdAt: string
  updatedAt: string
}

export interface Store {
  id: string
  name: string
  address: string
  phone: string
  managerId: string
  status: "active" | "inactive"
  createdAt: string
  updatedAt: string
}

export interface Product {
  id: string
  name: string
  description: string
  price: number
  categoryId: string
  image: string
  status: "active" | "inactive"
  createdAt: string
  updatedAt: string
}

export interface Category {
  id: string
  name: string
  status: "active" | "inactive"
  createdAt: string
  updatedAt: string
}

export interface Inventory {
  id: string
  productId: string
  storeId: string
  warehouseId: string
  currentStock: number
  minStock: number
  maxStock: number
  updatedAt: string
}

export interface Warehouse {
  id: string
  name: string
  address: string
  managerId: string
  status: "active" | "inactive"
  createdAt: string
  updatedAt: string
}

export interface Order {
  id: string
  storeId: string
  employeeId: string
  status: "pending" | "completed" | "cancelled"
  total: number
  paymentMethod: "cash" | "card" | "mobile"
  createdAt: string
  updatedAt: string
}

export interface OrderItem {
  id: string
  orderId: string
  productId: string
  quantity: number
  price: number
  subtotal: number
}

export interface CashRegister {
  id: string
  storeId: string
  employeeId: string
  openTime: string
  closeTime: string | null
  initialAmount: number
  finalAmount: number | null
  status: "open" | "closed"
}

export interface InventoryRequest {
  id: string
  fromStoreId: string
  toWarehouseId: string
  status: "pending" | "approved" | "rejected" | "completed"
  requestedBy: string
  approvedBy: string | null
  createdAt: string
  updatedAt: string
}

export interface InventoryRequestItem {
  id: string
  requestId: string
  productId: string
  quantity: number
  status: "pending" | "approved" | "rejected"
}

export interface SalesReport {
  storeId: string
  date: string
  totalSales: number
  totalOrders: number
  averageOrderValue: number
  topSellingProducts: {
    productId: string
    productName: string
    quantity: number
    revenue: number
  }[]
}

export type TimeOfDay = "morning" | "afternoon" | "night"

export interface BiometricData {
  id: string
  employeeId: string
  biometricType: "fingerprint" | "facialRecognition"
  biometricTemplate: string
  createdAt: string
  updatedAt: string
}
