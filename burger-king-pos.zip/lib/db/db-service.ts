import type {
  Employee,
  Store,
  Product,
  Category,
  Inventory,
  Warehouse,
  Order,
  OrderItem,
  CashRegister,
  InventoryRequest,
  InventoryRequestItem,
  SalesReport,
  BiometricData,
} from "../types/pos"

// Esta clase sería reemplazada por una implementación real de base de datos
// como Supabase, Firebase, o una API REST personalizada
class DBService {
  private employees: Employee[] = []
  private stores: Store[] = []
  private products: Product[] = []
  private categories: Category[] = []
  private inventory: Inventory[] = []
  private warehouses: Warehouse[] = []
  private orders: Order[] = []
  private orderItems: OrderItem[] = []
  private cashRegisters: CashRegister[] = []
  private inventoryRequests: InventoryRequest[] = []
  private inventoryRequestItems: InventoryRequestItem[] = []
  private biometricData: BiometricData[] = []

  constructor() {
    this.loadFromLocalStorage()

    // Inicializar con datos de ejemplo si está vacío
    if (this.categories.length === 0) {
      this.initializeData()
    }
  }

  private loadFromLocalStorage() {
    if (typeof window !== "undefined") {
      try {
        this.employees = JSON.parse(localStorage.getItem("employees") || "[]")
        this.stores = JSON.parse(localStorage.getItem("stores") || "[]")
        this.products = JSON.parse(localStorage.getItem("products") || "[]")
        this.categories = JSON.parse(localStorage.getItem("categories") || "[]")
        this.inventory = JSON.parse(localStorage.getItem("inventory") || "[]")
        this.warehouses = JSON.parse(localStorage.getItem("warehouses") || "[]")
        this.orders = JSON.parse(localStorage.getItem("orders") || "[]")
        this.orderItems = JSON.parse(localStorage.getItem("orderItems") || "[]")
        this.cashRegisters = JSON.parse(localStorage.getItem("cashRegisters") || "[]")
        this.inventoryRequests = JSON.parse(localStorage.getItem("inventoryRequests") || "[]")
        this.inventoryRequestItems = JSON.parse(localStorage.getItem("inventoryRequestItems") || "[]")
        this.biometricData = JSON.parse(localStorage.getItem("biometricData") || "[]")
      } catch (error) {
        console.error("Error loading data from localStorage:", error)
      }
    }
  }

  private saveToLocalStorage() {
    if (typeof window !== "undefined") {
      localStorage.setItem("employees", JSON.stringify(this.employees))
      localStorage.setItem("stores", JSON.stringify(this.stores))
      localStorage.setItem("products", JSON.stringify(this.products))
      localStorage.setItem("categories", JSON.stringify(this.categories))
      localStorage.setItem("inventory", JSON.stringify(this.inventory))
      localStorage.setItem("warehouses", JSON.stringify(this.warehouses))
      localStorage.setItem("orders", JSON.stringify(this.orders))
      localStorage.setItem("orderItems", JSON.stringify(this.orderItems))
      localStorage.setItem("cashRegisters", JSON.stringify(this.cashRegisters))
      localStorage.setItem("inventoryRequests", JSON.stringify(this.inventoryRequests))
      localStorage.setItem("inventoryRequestItems", JSON.stringify(this.inventoryRequestItems))
      localStorage.setItem("biometricData", JSON.stringify(this.biometricData))
    }
  }

  private initializeData() {
    // Agregar categorías predeterminadas
    const categories = [
      {
        id: "1",
        name: "Hamburguesas",
        status: "active" as const,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "2",
        name: "Acompañamientos",
        status: "active" as const,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "3",
        name: "Bebidas",
        status: "active" as const,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "4",
        name: "Postres",
        status: "active" as const,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "5",
        name: "Promociones",
        status: "active" as const,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ]
    this.categories = categories

    // Agregar usuario administrador predeterminado
    const admin: Employee = {
      id: "1",
      name: "Admin",
      email: "admin@burgerking.com",
      role: "admin",
      pin: "1234",
      storeId: "0", // Corporativo
      status: "active",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    this.employees = [admin]

    // Agregar sucursal predeterminada
    const store: Store = {
      id: "1",
      name: "Burger King Central",
      address: "Av. Principal 123",
      phone: "555-1234",
      managerId: "1",
      status: "active",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    this.stores = [store]

    // Agregar almacén predeterminado
    const warehouse: Warehouse = {
      id: "1",
      name: "Almacén Central",
      address: "Calle Industrial 456",
      managerId: "1",
      status: "active",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    this.warehouses = [warehouse]

    // Agregar productos predeterminados
    const products: Product[] = [
      {
        id: "1",
        name: "Whopper",
        description: "La hamburguesa clásica de Burger King",
        price: 89.9,
        categoryId: "1",
        image: "/classic-burger.png",
        status: "active",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "2",
        name: "Papas Fritas",
        description: "Papas fritas crujientes",
        price: 29.9,
        categoryId: "2",
        image: "/crispy-french-fries.png",
        status: "active",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "3",
        name: "Coca-Cola",
        description: "Refresco de cola",
        price: 25.9,
        categoryId: "3",
        image: "/refreshing-cola.png",
        status: "active",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "4",
        name: "Sundae",
        description: "Helado con topping de chocolate",
        price: 19.9,
        categoryId: "4",
        image: "/ice-cream-sundae.png",
        status: "active",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "5",
        name: "Combo Whopper",
        description: "Whopper + Papas + Refresco",
        price: 129.9,
        categoryId: "5",
        image: "/burger-combo.png",
        status: "active",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ]
    this.products = products

    // Agregar inventario inicial
    const inventory: Inventory[] = products.map((product) => ({
      id: `inv-${product.id}`,
      productId: product.id,
      storeId: "1",
      warehouseId: "1",
      currentStock: 100,
      minStock: 20,
      maxStock: 200,
      updatedAt: new Date().toISOString(),
    }))
    this.inventory = inventory

    this.saveToLocalStorage()
  }

  // Métodos para empleados
  async getEmployees(): Promise<Employee[]> {
    return this.employees
  }

  async getEmployeeById(id: string): Promise<Employee | null> {
    return this.employees.find((e) => e.id === id) || null
  }

  async createEmployee(employee: Omit<Employee, "id" | "createdAt" | "updatedAt">): Promise<Employee> {
    const newEmployee: Employee = {
      ...employee,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    this.employees.push(newEmployee)
    this.saveToLocalStorage()
    return newEmployee
  }

  async updateEmployee(id: string, data: Partial<Employee>): Promise<Employee | null> {
    const index = this.employees.findIndex((e) => e.id === id)
    if (index === -1) return null

    this.employees[index] = {
      ...this.employees[index],
      ...data,
      updatedAt: new Date().toISOString(),
    }
    this.saveToLocalStorage()
    return this.employees[index]
  }

  async deleteEmployee(id: string): Promise<boolean> {
    const initialLength = this.employees.length
    this.employees = this.employees.filter((e) => e.id !== id)
    this.saveToLocalStorage()
    return this.employees.length < initialLength
  }

  // Métodos para biometría
  async getBiometricDataByEmployeeId(employeeId: string): Promise<BiometricData | null> {
    return this.biometricData.find((b) => b.employeeId === employeeId) || null
  }

  async createBiometricData(data: Omit<BiometricData, "id" | "createdAt" | "updatedAt">): Promise<BiometricData> {
    const newBiometricData: BiometricData = {
      ...data,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    this.biometricData.push(newBiometricData)
    this.saveToLocalStorage()
    return newBiometricData
  }

  async updateBiometricData(
    employeeId: string,
    data: Partial<Omit<BiometricData, "id" | "employeeId">>,
  ): Promise<BiometricData | null> {
    const index = this.biometricData.findIndex((b) => b.employeeId === employeeId)
    if (index === -1) return null

    this.biometricData[index] = {
      ...this.biometricData[index],
      ...data,
      updatedAt: new Date().toISOString(),
    }
    this.saveToLocalStorage()
    return this.biometricData[index]
  }

  async deleteBiometricData(employeeId: string): Promise<boolean> {
    const initialLength = this.biometricData.length
    this.biometricData = this.biometricData.filter((b) => b.employeeId !== employeeId)
    this.saveToLocalStorage()
    return this.biometricData.length < initialLength
  }

  async authenticateWithBiometric(biometricTemplate: string): Promise<Employee | null> {
    // En una implementación real, esto utilizaría un algoritmo de comparación biométrica
    // Para esta demo, simplemente buscamos una coincidencia exacta
    const bioData = this.biometricData.find((b) => b.biometricTemplate === biometricTemplate)
    if (!bioData) return null

    return this.employees.find((e) => e.id === bioData.employeeId && e.status === "active") || null
  }

  // Métodos para sucursales
  async getStores(): Promise<Store[]> {
    return this.stores
  }

  async getStoreById(id: string): Promise<Store | null> {
    return this.stores.find((s) => s.id === id) || null
  }

  async createStore(store: Omit<Store, "id" | "createdAt" | "updatedAt">): Promise<Store> {
    const newStore: Store = {
      ...store,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    this.stores.push(newStore)
    this.saveToLocalStorage()
    return newStore
  }

  async updateStore(id: string, data: Partial<Store>): Promise<Store | null> {
    const index = this.stores.findIndex((s) => s.id === id)
    if (index === -1) return null

    this.stores[index] = {
      ...this.stores[index],
      ...data,
      updatedAt: new Date().toISOString(),
    }
    this.saveToLocalStorage()
    return this.stores[index]
  }

  async deleteStore(id: string): Promise<boolean> {
    const initialLength = this.stores.length
    this.stores = this.stores.filter((s) => s.id !== id)
    this.saveToLocalStorage()
    return this.stores.length < initialLength
  }

  // Métodos para productos
  async getProducts(): Promise<Product[]> {
    return this.products
  }

  async getProductById(id: string): Promise<Product | null> {
    return this.products.find((p) => p.id === id) || null
  }

  async getProductsByCategory(categoryId: string): Promise<Product[]> {
    return this.products.filter((p) => p.categoryId === categoryId && p.status === "active")
  }

  async createProduct(product: Omit<Product, "id" | "createdAt" | "updatedAt">): Promise<Product> {
    const newProduct: Product = {
      ...product,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    this.products.push(newProduct)
    this.saveToLocalStorage()
    return newProduct
  }

  async updateProduct(id: string, data: Partial<Product>): Promise<Product | null> {
    const index = this.products.findIndex((p) => p.id === id)
    if (index === -1) return null

    this.products[index] = {
      ...this.products[index],
      ...data,
      updatedAt: new Date().toISOString(),
    }
    this.saveToLocalStorage()
    return this.products[index]
  }

  async deleteProduct(id: string): Promise<boolean> {
    const initialLength = this.products.length
    this.products = this.products.filter((p) => p.id !== id)
    this.saveToLocalStorage()
    return this.products.length < initialLength
  }

  // Métodos para categorías
  async getCategories(): Promise<Category[]> {
    return this.categories
  }

  async getCategoryById(id: string): Promise<Category | null> {
    return this.categories.find((c) => c.id === id) || null
  }

  async createCategory(category: Omit<Category, "id" | "createdAt" | "updatedAt">): Promise<Category> {
    const newCategory: Category = {
      ...category,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    this.categories.push(newCategory)
    this.saveToLocalStorage()
    return newCategory
  }

  async updateCategory(id: string, data: Partial<Category>): Promise<Category | null> {
    const index = this.categories.findIndex((c) => c.id === id)
    if (index === -1) return null

    this.categories[index] = {
      ...this.categories[index],
      ...data,
      updatedAt: new Date().toISOString(),
    }
    this.saveToLocalStorage()
    return this.categories[index]
  }

  async deleteCategory(id: string): Promise<boolean> {
    const initialLength = this.categories.length
    this.categories = this.categories.filter((c) => c.id !== id)
    this.saveToLocalStorage()
    return this.categories.length < initialLength
  }

  // Métodos para inventario
  async getInventory(): Promise<Inventory[]> {
    return this.inventory
  }

  async getInventoryByStore(storeId: string): Promise<Inventory[]> {
    return this.inventory.filter((i) => i.storeId === storeId)
  }

  async getInventoryByWarehouse(warehouseId: string): Promise<Inventory[]> {
    return this.inventory.filter((i) => i.warehouseId === warehouseId)
  }

  async getInventoryByProduct(productId: string): Promise<Inventory[]> {
    return this.inventory.filter((i) => i.productId === productId)
  }

  async getInventoryItem(productId: string, storeId: string): Promise<Inventory | null> {
    return this.inventory.find((i) => i.productId === productId && i.storeId === storeId) || null
  }

  async updateInventory(productId: string, storeId: string, quantity: number): Promise<Inventory | null> {
    const index = this.inventory.findIndex((i) => i.productId === productId && i.storeId === storeId)
    if (index === -1) return null

    this.inventory[index] = {
      ...this.inventory[index],
      currentStock: quantity,
      updatedAt: new Date().toISOString(),
    }
    this.saveToLocalStorage()
    return this.inventory[index]
  }

  // Métodos para órdenes
  async getOrders(): Promise<Order[]> {
    return this.orders
  }

  async getOrdersByStore(storeId: string): Promise<Order[]> {
    return this.orders.filter((o) => o.storeId === storeId)
  }

  async getOrderById(id: string): Promise<Order | null> {
    return this.orders.find((o) => o.id === id) || null
  }

  async getOrderItems(orderId: string): Promise<OrderItem[]> {
    return this.orderItems.filter((oi) => oi.orderId === orderId)
  }

  async createOrder(
    order: Omit<Order, "id" | "createdAt" | "updatedAt">,
    items: Omit<OrderItem, "id" | "orderId">[],
  ): Promise<Order> {
    const orderId = Date.now().toString()
    const newOrder: Order = {
      ...order,
      id: orderId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    this.orders.push(newOrder)

    // Crear items de la orden
    const newItems = items.map((item, index) => ({
      ...item,
      id: `${orderId}-${index}`,
      orderId,
    }))

    this.orderItems.push(...newItems)

    // Actualizar inventario
    for (const item of items) {
      const inventoryItem = await this.getInventoryItem(item.productId, order.storeId)
      if (inventoryItem) {
        await this.updateInventory(item.productId, order.storeId, inventoryItem.currentStock - item.quantity)
      }
    }

    this.saveToLocalStorage()
    return newOrder
  }

  async updateOrderStatus(id: string, status: Order["status"]): Promise<Order | null> {
    const index = this.orders.findIndex((o) => o.id === id)
    if (index === -1) return null

    this.orders[index] = {
      ...this.orders[index],
      status,
      updatedAt: new Date().toISOString(),
    }
    this.saveToLocalStorage()
    return this.orders[index]
  }

  // Métodos para caja registradora
  async getCashRegisters(): Promise<CashRegister[]> {
    return this.cashRegisters
  }

  async getCashRegistersByStore(storeId: string): Promise<CashRegister[]> {
    return this.cashRegisters.filter((cr) => cr.storeId === storeId)
  }

  async getOpenCashRegister(storeId: string, employeeId: string): Promise<CashRegister | null> {
    return (
      this.cashRegisters.find((cr) => cr.storeId === storeId && cr.employeeId === employeeId && cr.status === "open") ||
      null
    )
  }

  async openCashRegister(
    register: Omit<CashRegister, "id" | "closeTime" | "finalAmount" | "status">,
  ): Promise<CashRegister> {
    const newRegister: CashRegister = {
      ...register,
      id: Date.now().toString(),
      closeTime: null,
      finalAmount: null,
      status: "open",
    }

    this.cashRegisters.push(newRegister)
    this.saveToLocalStorage()
    return newRegister
  }

  async closeCashRegister(id: string, finalAmount: number): Promise<CashRegister | null> {
    const index = this.cashRegisters.findIndex((cr) => cr.id === id)
    if (index === -1) return null

    this.cashRegisters[index] = {
      ...this.cashRegisters[index],
      closeTime: new Date().toISOString(),
      finalAmount,
      status: "closed",
    }
    this.saveToLocalStorage()
    return this.cashRegisters[index]
  }

  // Métodos para almacenes
  async getWarehouses(): Promise<Warehouse[]> {
    return this.warehouses
  }

  async getWarehouseById(id: string): Promise<Warehouse | null> {
    return this.warehouses.find((w) => w.id === id) || null
  }

  async createWarehouse(warehouse: Omit<Warehouse, "id" | "createdAt" | "updatedAt">): Promise<Warehouse> {
    const newWarehouse: Warehouse = {
      ...warehouse,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    this.warehouses.push(newWarehouse)
    this.saveToLocalStorage()
    return newWarehouse
  }

  async updateWarehouse(id: string, data: Partial<Warehouse>): Promise<Warehouse | null> {
    const index = this.warehouses.findIndex((w) => w.id === id)
    if (index === -1) return null

    this.warehouses[index] = {
      ...this.warehouses[index],
      ...data,
      updatedAt: new Date().toISOString(),
    }
    this.saveToLocalStorage()
    return this.warehouses[index]
  }

  async deleteWarehouse(id: string): Promise<boolean> {
    const initialLength = this.warehouses.length
    this.warehouses = this.warehouses.filter((w) => w.id !== id)
    this.saveToLocalStorage()
    return this.warehouses.length < initialLength
  }

  // Métodos para solicitudes de inventario
  async getInventoryRequests(): Promise<InventoryRequest[]> {
    return this.inventoryRequests
  }

  async getInventoryRequestsByStore(storeId: string): Promise<InventoryRequest[]> {
    return this.inventoryRequests.filter((ir) => ir.fromStoreId === storeId)
  }

  async getInventoryRequestsByWarehouse(warehouseId: string): Promise<InventoryRequest[]> {
    return this.inventoryRequests.filter((ir) => ir.toWarehouseId === warehouseId)
  }

  async getInventoryRequestById(id: string): Promise<InventoryRequest | null> {
    return this.inventoryRequests.find((ir) => ir.id === id) || null
  }

  async getInventoryRequestItems(requestId: string): Promise<InventoryRequestItem[]> {
    return this.inventoryRequestItems.filter((iri) => iri.requestId === requestId)
  }

  async createInventoryRequest(
    request: Omit<InventoryRequest, "id" | "createdAt" | "updatedAt">,
    items: Omit<InventoryRequestItem, "id" | "requestId">[],
  ): Promise<InventoryRequest> {
    const requestId = Date.now().toString()
    const newRequest: InventoryRequest = {
      ...request,
      id: requestId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    this.inventoryRequests.push(newRequest)

    // Crear items de la solicitud
    const newItems = items.map((item, index) => ({
      ...item,
      id: `${requestId}-${index}`,
      requestId,
    }))

    this.inventoryRequestItems.push(...newItems)
    this.saveToLocalStorage()
    return newRequest
  }

  async updateInventoryRequestStatus(
    id: string,
    status: InventoryRequest["status"],
    approvedBy?: string,
  ): Promise<InventoryRequest | null> {
    const index = this.inventoryRequests.findIndex((ir) => ir.id === id)
    if (index === -1) return null

    this.inventoryRequests[index] = {
      ...this.inventoryRequests[index],
      status,
      approvedBy: approvedBy || this.inventoryRequests[index].approvedBy,
      updatedAt: new Date().toISOString(),
    }
    this.saveToLocalStorage()
    return this.inventoryRequests[index]
  }

  // Métodos para reportes de ventas
  async getSalesReportByStore(storeId: string, startDate: string, endDate: string): Promise<SalesReport> {
    // Filtrar órdenes por tienda y rango de fechas
    const storeOrders = this.orders.filter(
      (o) => o.storeId === storeId && o.status === "completed" && o.createdAt >= startDate && o.createdAt <= endDate,
    )

    // Calcular ventas totales y órdenes
    const totalSales = storeOrders.reduce((sum, order) => sum + order.total, 0)
    const totalOrders = storeOrders.length
    const averageOrderValue = totalOrders > 0 ? totalSales / totalOrders : 0

    // Obtener todos los items de estas órdenes
    const orderIds = storeOrders.map((o) => o.id)
    const allOrderItems = this.orderItems.filter((oi) => orderIds.includes(oi.orderId))

    // Calcular productos más vendidos
    const productSales: Record<string, { quantity: number; revenue: number }> = {}

    for (const item of allOrderItems) {
      if (!productSales[item.productId]) {
        productSales[item.productId] = { quantity: 0, revenue: 0 }
      }
      productSales[item.productId].quantity += item.quantity
      productSales[item.productId].revenue += item.subtotal
    }

    // Convertir a array y ordenar por ingresos
    const topSellingProducts = await Promise.all(
      Object.entries(productSales).map(async ([productId, data]) => {
        const product = await this.getProductById(productId)
        return {
          productId,
          productName: product?.name || "Producto Desconocido",
          quantity: data.quantity,
          revenue: data.revenue,
        }
      }),
    )

    // Ordenar por ingresos (mayor primero)
    topSellingProducts.sort((a, b) => b.revenue - a.revenue)

    return {
      storeId,
      date: new Date().toISOString(),
      totalSales,
      totalOrders,
      averageOrderValue,
      topSellingProducts: topSellingProducts.slice(0, 5), // Top 5 productos
    }
  }

  // Métodos de autenticación
  async authenticateEmployee(pin: string): Promise<Employee | null> {
    return this.employees.find((e) => e.pin === pin && e.status === "active") || null
  }
}

// Crear una instancia singleton
let dbService: DBService

export function getDBService(): DBService {
  if (typeof window !== "undefined" && !dbService) {
    dbService = new DBService()
  }
  return dbService as DBService
}
