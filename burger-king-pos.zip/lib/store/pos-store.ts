import { create } from "zustand"
import { persist } from "zustand/middleware"
import type { Employee, Store, Product, Category, Inventory, Order, OrderItem, CashRegister } from "../types/pos"
import { getDBService } from "../db/db-service"
import { getBiometricService } from "../services/biometric-service"

export interface POSState {
  // Autenticación
  currentUser: Employee | null
  currentStore: Store | null
  isAuthenticated: boolean

  // Transacción actual
  currentOrder: Order | null
  currentOrderItems: OrderItem[]

  // Caja registradora
  currentCashRegister: CashRegister | null

  // Datos
  categories: Category[]
  products: Record<string, Product>
  productsByCategory: Record<string, Product[]>
  inventory: Inventory[]

  // Estados de carga
  isLoading: boolean
  error: string | null

  // Acciones de autenticación
  loginWithPIN: (pin: string, storeId: string) => Promise<boolean>
  loginWithBiometric: (biometricType: "fingerprint" | "facialRecognition") => Promise<boolean>
  logout: () => void

  // Acciones de orden
  createOrder: () => void
  addItemToOrder: (product: Product, quantity: number) => void
  removeItemFromOrder: (itemId: string) => void
  updateItemQuantity: (itemId: string, quantity: number) => void
  completeOrder: (paymentMethod: "cash" | "card" | "mobile") => Promise<boolean>
  cancelOrder: () => void

  // Acciones de caja registradora
  openCashRegister: (initialAmount: number) => Promise<boolean>
  closeCashRegister: (finalAmount: number) => Promise<boolean>

  // Obtención de datos
  fetchCategories: () => Promise<void>
  fetchAllProducts: () => Promise<void>
  fetchProductsByCategory: (categoryId: string) => Promise<void>
  fetchInventory: (storeId: string) => Promise<void>

  // Biometría
  registerBiometric: (employeeId: string, biometricType: "fingerprint" | "facialRecognition") => Promise<boolean>
}

const usePOSStore = create<POSState>()(
  persist(
    (set, get) => ({
      // Estado inicial
      currentUser: null,
      currentStore: null,
      isAuthenticated: false,
      currentOrder: null,
      currentOrderItems: [],
      currentCashRegister: null,
      categories: [],
      products: {},
      productsByCategory: {},
      inventory: [],
      isLoading: false,
      error: null,

      // Acciones de autenticación
      loginWithPIN: async (pin: string, storeId: string) => {
        set({ isLoading: true, error: null })
        try {
          const db = getDBService()
          const employee = await db.authenticateEmployee(pin)

          if (!employee) {
            set({ error: "PIN inválido", isLoading: false })
            return false
          }

          const store = await db.getStoreById(storeId)
          if (!store) {
            set({ error: "Sucursal no encontrada", isLoading: false })
            return false
          }

          set({
            currentUser: employee,
            currentStore: store,
            isAuthenticated: true,
            isLoading: false,
          })

          // Verificar si hay una caja abierta
          const openRegister = await db.getOpenCashRegister(storeId, employee.id)
          if (openRegister) {
            set({ currentCashRegister: openRegister })
          }

          // Cargar datos iniciales
          await get().fetchCategories()
          await get().fetchAllProducts()
          await get().fetchInventory(storeId)

          return true
        } catch (error) {
          set({ error: "Error al iniciar sesión", isLoading: false })
          return false
        }
      },

      loginWithBiometric: async (biometricType: "fingerprint" | "facialRecognition") => {
        set({ isLoading: true, error: null })
        try {
          const bioService = getBiometricService()

          // Capturar datos biométricos
          let biometricTemplate = ""
          if (biometricType === "fingerprint") {
            biometricTemplate = await bioService.captureFingerprint()
          } else {
            biometricTemplate = await bioService.captureFacialRecognition()
          }

          // Autenticar con los datos biométricos
          const employee = await bioService.authenticateWithBiometric(biometricTemplate)

          if (!employee) {
            set({ error: "Autenticación biométrica fallida", isLoading: false })
            return false
          }

          // Obtener la sucursal
          const db = getDBService()
          const store = await db.getStoreById(employee.storeId)

          if (!store) {
            set({ error: "Sucursal no encontrada", isLoading: false })
            return false
          }

          set({
            currentUser: employee,
            currentStore: store,
            isAuthenticated: true,
            isLoading: false,
          })

          // Verificar si hay una caja abierta
          const openRegister = await db.getOpenCashRegister(store.id, employee.id)
          if (openRegister) {
            set({ currentCashRegister: openRegister })
          }

          // Cargar datos iniciales
          await get().fetchCategories()
          await get().fetchAllProducts()
          await get().fetchInventory(store.id)

          return true
        } catch (error) {
          set({ error: "Error en autenticación biométrica", isLoading: false })
          return false
        }
      },

      logout: () => {
        set({
          currentUser: null,
          currentStore: null,
          isAuthenticated: false,
          currentOrder: null,
          currentOrderItems: [],
          currentCashRegister: null,
        })
      },

      // Acciones de orden
      createOrder: () => {
        const { currentUser, currentStore } = get()
        if (!currentUser || !currentStore) return

        const newOrder: Order = {
          id: `temp-${Date.now()}`,
          storeId: currentStore.id,
          employeeId: currentUser.id,
          status: "pending",
          total: 0,
          paymentMethod: "cash", // Valor predeterminado
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        }

        set({
          currentOrder: newOrder,
          currentOrderItems: [],
        })
      },

      addItemToOrder: (product: Product, quantity: number) => {
        const { currentOrder, currentOrderItems } = get()
        if (!currentOrder) return

        // Verificar si el producto ya existe en la orden
        const existingItemIndex = currentOrderItems.findIndex((item) => item.productId === product.id)

        if (existingItemIndex >= 0) {
          // Actualizar item existente
          const updatedItems = [...currentOrderItems]
          const newQuantity = updatedItems[existingItemIndex].quantity + quantity
          updatedItems[existingItemIndex] = {
            ...updatedItems[existingItemIndex],
            quantity: newQuantity,
            subtotal: newQuantity * product.price,
          }

          const total = updatedItems.reduce((sum, item) => sum + item.subtotal, 0)

          set({
            currentOrderItems: updatedItems,
            currentOrder: {
              ...currentOrder,
              total,
              updatedAt: new Date().toISOString(),
            },
          })
        } else {
          // Agregar nuevo item
          const newItem: OrderItem = {
            id: `temp-${Date.now()}-${product.id}`,
            orderId: currentOrder.id,
            productId: product.id,
            quantity,
            price: product.price,
            subtotal: quantity * product.price,
          }

          const updatedItems = [...currentOrderItems, newItem]
          const total = updatedItems.reduce((sum, item) => sum + item.subtotal, 0)

          set({
            currentOrderItems: updatedItems,
            currentOrder: {
              ...currentOrder,
              total,
              updatedAt: new Date().toISOString(),
            },
          })
        }
      },

      removeItemFromOrder: (itemId: string) => {
        const { currentOrder, currentOrderItems } = get()
        if (!currentOrder) return

        const updatedItems = currentOrderItems.filter((item) => item.id !== itemId)
        const total = updatedItems.reduce((sum, item) => sum + item.subtotal, 0)

        set({
          currentOrderItems: updatedItems,
          currentOrder: {
            ...currentOrder,
            total,
            updatedAt: new Date().toISOString(),
          },
        })
      },

      updateItemQuantity: (itemId: string, quantity: number) => {
        const { currentOrder, currentOrderItems } = get()
        if (!currentOrder) return

        const updatedItems = currentOrderItems.map((item) => {
          if (item.id === itemId) {
            return {
              ...item,
              quantity,
              subtotal: quantity * item.price,
            }
          }
          return item
        })

        const total = updatedItems.reduce((sum, item) => sum + item.subtotal, 0)

        set({
          currentOrderItems: updatedItems,
          currentOrder: {
            ...currentOrder,
            total,
            updatedAt: new Date().toISOString(),
          },
        })
      },

      completeOrder: async (paymentMethod: "cash" | "card" | "mobile") => {
        const { currentOrder, currentOrderItems, currentUser, currentStore } = get()
        if (!currentOrder || !currentUser || !currentStore || currentOrderItems.length === 0) {
          return false
        }

        set({ isLoading: true, error: null })

        try {
          const db = getDBService()

          // Crear la orden en la base de datos
          const orderData: Omit<Order, "id" | "createdAt" | "updatedAt"> = {
            storeId: currentStore.id,
            employeeId: currentUser.id,
            status: "completed",
            total: currentOrder.total,
            paymentMethod,
          }

          const orderItems = currentOrderItems.map((item) => ({
            productId: item.productId,
            quantity: item.quantity,
            price: item.price,
            subtotal: item.subtotal,
          }))

          await db.createOrder(orderData, orderItems)

          // Limpiar orden actual
          set({
            currentOrder: null,
            currentOrderItems: [],
            isLoading: false,
          })

          // Refrescar inventario
          await get().fetchInventory(currentStore.id)

          // Crear nueva orden automáticamente
          get().createOrder()

          return true
        } catch (error) {
          set({ error: "Error al completar la orden", isLoading: false })
          return false
        }
      },

      cancelOrder: () => {
        set({
          currentOrder: null,
          currentOrderItems: [],
        })

        // Crear nueva orden automáticamente
        get().createOrder()
      },

      // Acciones de caja registradora
      openCashRegister: async (initialAmount: number) => {
        const { currentUser, currentStore } = get()
        if (!currentUser || !currentStore) return false

        set({ isLoading: true, error: null })

        try {
          const db = getDBService()

          const registerData = {
            storeId: currentStore.id,
            employeeId: currentUser.id,
            openTime: new Date().toISOString(),
            initialAmount,
          }

          const register = await db.openCashRegister(registerData)
          set({ currentCashRegister: register, isLoading: false })
          return true
        } catch (error) {
          set({ error: "Error al abrir caja", isLoading: false })
          return false
        }
      },

      closeCashRegister: async (finalAmount: number) => {
        const { currentCashRegister } = get()
        if (!currentCashRegister) return false

        set({ isLoading: true, error: null })

        try {
          const db = getDBService()
          await db.closeCashRegister(currentCashRegister.id, finalAmount)
          set({ currentCashRegister: null, isLoading: false })
          return true
        } catch (error) {
          set({ error: "Error al cerrar caja", isLoading: false })
          return false
        }
      },

      // Obtención de datos
      fetchCategories: async () => {
        set({ isLoading: true, error: null })

        try {
          const db = getDBService()
          const categories = await db.getCategories()
          set({ categories, isLoading: false })
        } catch (error) {
          set({ error: "Error al obtener categorías", isLoading: false })
        }
      },

      fetchAllProducts: async () => {
        set({ isLoading: true, error: null })

        try {
          const db = getDBService()
          const allProducts = await db.getProducts()

          // Crear mapa de productos por ID para acceso rápido
          const productsMap: Record<string, Product> = {}
          allProducts.forEach((product) => {
            productsMap[product.id] = product
          })

          // Organizar productos por categoría
          const productsByCat: Record<string, Product[]> = {}
          allProducts.forEach((product) => {
            if (!productsByCat[product.categoryId]) {
              productsByCat[product.categoryId] = []
            }
            productsByCat[product.categoryId].push(product)
          })

          set({
            products: productsMap,
            productsByCategory: productsByCat,
            isLoading: false,
          })
        } catch (error) {
          set({ error: "Error al obtener productos", isLoading: false })
        }
      },

      fetchProductsByCategory: async (categoryId: string) => {
        set({ isLoading: true, error: null })

        try {
          const db = getDBService()
          const products = await db.getProductsByCategory(categoryId)

          // Actualizar el mapa de productos por categoría
          const { productsByCategory } = get()
          set({
            productsByCategory: {
              ...productsByCategory,
              [categoryId]: products,
            },
            isLoading: false,
          })
        } catch (error) {
          set({ error: "Error al obtener productos por categoría", isLoading: false })
        }
      },

      fetchInventory: async (storeId: string) => {
        set({ isLoading: true, error: null })

        try {
          const db = getDBService()
          const inventory = await db.getInventoryByStore(storeId)
          set({ inventory, isLoading: false })
        } catch (error) {
          set({ error: "Error al obtener inventario", isLoading: false })
        }
      },

      // Biometría
      registerBiometric: async (employeeId: string, biometricType: "fingerprint" | "facialRecognition") => {
        set({ isLoading: true, error: null })

        try {
          const bioService = getBiometricService()

          // Capturar datos biométricos
          let biometricTemplate = ""
          if (biometricType === "fingerprint") {
            biometricTemplate = await bioService.captureFingerprint()
          } else {
            biometricTemplate = await bioService.captureFacialRecognition()
          }

          // Registrar los datos biométricos
          const success = await bioService.registerBiometric(employeeId, biometricType, biometricTemplate)

          set({ isLoading: false })
          return success
        } catch (error) {
          set({ error: "Error al registrar datos biométricos", isLoading: false })
          return false
        }
      },
    }),
    {
      name: "pos-storage",
    },
  ),
)

export default usePOSStore
