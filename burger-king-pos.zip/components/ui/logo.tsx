import Image from "next/image"

export default function Logo({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center ${className}`}>
      <div className="relative w-10 h-10 mr-2">
        <Image
          src="/burger-king-logo.png"
          alt="Burger King Logo"
          width={40}
          height={40}
          className="object-contain"
        />
      </div>
      <span className="font-bold text-xl">Burger King</span>
    </div>
  )
}
