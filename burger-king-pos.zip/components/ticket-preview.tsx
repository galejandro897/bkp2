"use client"

import { useRef } from "react"
import { Printer } from "lucide-react"
import type { Order, OrderItem, Product, Store, Employee } from "@/lib/types/pos"

interface TicketPreviewProps {
  order: Order
  orderItems: OrderItem[]
  products: Record<string, Product>
  store: Store
  employee: Employee
  onPrint: () => void
}

export default function TicketPreview({ order, orderItems, products, store, employee, onPrint }: TicketPreviewProps) {
  const ticketRef = useRef<HTMLDivElement>(null)

  const subtotal = orderItems.reduce((sum, item) => sum + item.subtotal, 0)
  const tax = subtotal * 0.16 // 16% IVA
  const total = subtotal + tax

  // Formatear número de orden
  const orderNumber = `#${order.id.toString().padStart(6, "0")}`

  // Formatear fecha
  const orderDate = new Date(order.createdAt)
  const formattedDate = orderDate.toLocaleDateString("es-MX", {
    year: "numeric",
    month: "long",
    day: "numeric",
  })

  const formattedTime = orderDate.toLocaleTimeString("es-MX", {
    hour: "2-digit",
    minute: "2-digit",
  })

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 max-w-md mx-auto">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-bold">Vista Previa del Ticket</h2>
        <button onClick={onPrint} className="flex items-center text-red-600 hover:text-red-800">
          <Printer size={20} className="mr-1" />
          <span>Imprimir</span>
        </button>
      </div>

      <div
        ref={ticketRef}
        className="bg-white border rounded-lg p-4 font-mono text-sm"
        style={{ width: "80mm", margin: "0 auto" }}
      >
        <div className="text-center mb-4">
          <div className="font-bold text-lg mb-1">BURGER KING</div>
          <div>{store.name}</div>
          <div className="text-xs">{store.address}</div>
          <div className="text-xs">Tel: {store.phone}</div>
        </div>

        <div className="flex justify-between text-xs mb-2">
          <span>Orden: {orderNumber}</span>
          <span>Cajero: {employee.name}</span>
        </div>

        <div className="text-xs mb-4">
          <div>Fecha: {formattedDate}</div>
          <div>Hora: {formattedTime}</div>
        </div>

        <div className="border-t border-b py-2 mb-2">
          <div className="flex justify-between text-xs font-bold">
            <span className="w-8">Cant</span>
            <span className="flex-1">Descripción</span>
            <span className="w-16 text-right">Precio</span>
            <span className="w-16 text-right">Importe</span>
          </div>
        </div>

        {orderItems.map((item) => {
          const product = products[item.productId]
          return (
            <div key={item.id} className="flex justify-between text-xs mb-1">
              <span className="w-8">{item.quantity}</span>
              <span className="flex-1">{product?.name || "Producto desconocido"}</span>
              <span className="w-16 text-right">${item.price.toFixed(2)}</span>
              <span className="w-16 text-right">${item.subtotal.toFixed(2)}</span>
            </div>
          )
        })}

        <div className="border-t mt-4 pt-2">
          <div className="flex justify-between text-xs">
            <span>Subtotal:</span>
            <span>${subtotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-xs">
            <span>IVA (16%):</span>
            <span>${tax.toFixed(2)}</span>
          </div>
          <div className="flex justify-between font-bold mt-1">
            <span>TOTAL:</span>
            <span>${total.toFixed(2)}</span>
          </div>
        </div>

        <div className="mt-4 text-center text-xs">
          <div className="font-bold">
            {order.paymentMethod === "cash"
              ? "PAGO EN EFECTIVO"
              : order.paymentMethod === "card"
                ? "PAGO CON TARJETA"
                : "PAGO MÓVIL"}
          </div>
          <div className="mt-4">¡Gracias por su preferencia!</div>
          <div>www.burgerking.com.mx</div>
        </div>
      </div>
    </div>
  )
}
