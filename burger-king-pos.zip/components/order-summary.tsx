"use client"

import { useState } from "react"
import { Trash2, Plus, Minus, Printer } from "lucide-react"
import type { Order, OrderItem, Product } from "@/lib/types/pos"

interface OrderSummaryProps {
  order: Order | null
  orderItems: OrderItem[]
  products: Record<string, Product>
  onRemoveItem: (itemId: string) => void
  onUpdateQuantity: (itemId: string, quantity: number) => void
  onCompleteOrder: (paymentMethod: "cash" | "card" | "mobile") => void
  onCancelOrder: () => void
  onPrintTicket?: () => void
}

export default function OrderSummary({
  order,
  orderItems,
  products,
  onRemoveItem,
  onUpdateQuantity,
  onCompleteOrder,
  onCancelOrder,
  onPrintTicket,
}: OrderSummaryProps) {
  const [showPaymentOptions, setShowPaymentOptions] = useState(false)
  const [showOrderComplete, setShowOrderComplete] = useState(false)

  if (!order) {
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <div className="text-gray-400 text-center">
          <p className="text-lg font-medium">No hay orden activa</p>
          <p className="text-sm">Crea una nueva orden para comenzar</p>
        </div>
      </div>
    )
  }

  const handlePayment = (method: "cash" | "card" | "mobile") => {
    onCompleteOrder(method)
    setShowPaymentOptions(false)
    setShowOrderComplete(true)

    // Ocultar mensaje de completado después de 3 segundos
    setTimeout(() => {
      setShowOrderComplete(false)
    }, 3000)
  }

  const subtotal = orderItems.reduce((sum, item) => sum + item.subtotal, 0)
  const tax = subtotal * 0.16 // 16% IVA
  const total = subtotal + tax

  // Formatear número de orden
  const orderNumber = `#${order.id.toString().padStart(6, "0")}`

  return (
    <div className="flex flex-col h-full">
      {showOrderComplete ? (
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="bg-green-100 text-green-800 p-6 rounded-lg text-center">
            <div className="text-5xl mb-4">✓</div>
            <h3 className="text-xl font-bold mb-2">¡Orden Completada!</h3>
            <p className="mb-4">La orden {orderNumber} ha sido procesada correctamente.</p>
            <button
              onClick={onPrintTicket}
              className="flex items-center justify-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
            >
              <Printer size={18} className="mr-2" />
              Imprimir Ticket
            </button>
          </div>
        </div>
      ) : (
        <>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">Orden {orderNumber}</h2>
            <span className="text-sm text-gray-500">{new Date(order.createdAt).toLocaleTimeString()}</span>
          </div>

          {orderItems.length === 0 ? (
            <div className="flex-1 flex items-center justify-center">
              <p className="text-gray-400">No hay productos en la orden</p>
            </div>
          ) : (
            <div className="flex-1 overflow-y-auto">
              <ul className="space-y-3">
                {orderItems.map((item) => {
                  const product = products[item.productId]
                  return (
                    <li key={item.id} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                      <div className="flex-1">
                        <p className="font-medium">{product?.name || "Producto desconocido"}</p>
                        <p className="text-sm text-gray-500">${item.price.toFixed(2)} c/u</p>
                      </div>

                      <div className="flex items-center space-x-3">
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => onUpdateQuantity(item.id, Math.max(1, item.quantity - 1))}
                            className="p-1 rounded-full bg-gray-200 hover:bg-gray-300"
                          >
                            <Minus size={14} />
                          </button>

                          <span className="w-8 text-center">{item.quantity}</span>

                          <button
                            onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                            className="p-1 rounded-full bg-gray-200 hover:bg-gray-300"
                          >
                            <Plus size={14} />
                          </button>
                        </div>

                        <span className="font-medium w-20 text-right">${item.subtotal.toFixed(2)}</span>

                        <button onClick={() => onRemoveItem(item.id)} className="p-1 text-red-500 hover:text-red-700">
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </li>
                  )
                })}
              </ul>
            </div>
          )}

          <div className="mt-4 pt-4 border-t">
            <div className="flex justify-between mb-2">
              <span className="text-gray-600">Subtotal:</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between mb-2">
              <span className="text-gray-600">IVA (16%):</span>
              <span>${tax.toFixed(2)}</span>
            </div>
            <div className="flex justify-between mb-4">
              <span className="font-bold">Total:</span>
              <span className="font-bold">${total.toFixed(2)}</span>
            </div>

            {showPaymentOptions ? (
              <div className="space-y-2">
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => handlePayment("cash")}
                    className="py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                  >
                    Efectivo
                  </button>
                  <button
                    onClick={() => handlePayment("card")}
                    className="py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    Tarjeta
                  </button>
                  <button
                    onClick={() => handlePayment("mobile")}
                    className="py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
                  >
                    Móvil
                  </button>
                </div>
                <button
                  onClick={() => setShowPaymentOptions(false)}
                  className="w-full py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
                >
                  Cancelar
                </button>
              </div>
            ) : (
              <div className="flex space-x-2">
                <button
                  onClick={onCancelOrder}
                  className="flex-1 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
                  disabled={orderItems.length === 0}
                >
                  Cancelar
                </button>
                <button
                  onClick={() => setShowPaymentOptions(true)}
                  className="flex-1 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                  disabled={orderItems.length === 0}
                >
                  Pagar
                </button>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  )
}
