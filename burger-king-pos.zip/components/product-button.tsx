"use client"

import { useState } from "react"
import Image from "next/image"
import type { Product, Inventory } from "@/lib/types/pos"

interface ProductButtonProps {
  product: Product
  inventory?: Inventory
  onClick: (product: Product) => void
  disabled?: boolean
}

export default function ProductButton({ product, inventory, onClick, disabled = false }: ProductButtonProps) {
  const [isHovered, setIsHovered] = useState(false)

  const handleClick = () => {
    if (!disabled) {
      onClick(product)
    }
  }

  const stock = inventory?.currentStock || 0
  const lowStock = inventory && inventory.minStock && stock <= inventory.minStock

  return (
    <button
      className={`relative flex flex-col items-center justify-between p-3 rounded-lg transition-all ${
        disabled
          ? "bg-gray-100 cursor-not-allowed opacity-60"
          : isHovered
            ? "bg-red-50 shadow-md"
            : "bg-white shadow-sm hover:shadow-md"
      }`}
      onClick={handleClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      disabled={disabled}
    >
      <div className="relative w-full aspect-square mb-2 rounded-md overflow-hidden">
        <Image
          src={product.image || `/placeholder.svg?height=200&width=200&query=${encodeURIComponent(product.name)}`}
          alt={product.name}
          width={200}
          height={200}
          className="object-cover"
        />
      </div>

      <div className="w-full text-center">
        <h3 className="font-medium text-sm line-clamp-2">{product.name}</h3>
        <p className="font-bold text-red-600">${product.price.toFixed(2)}</p>
      </div>

      {inventory && (
        <div
          className={`absolute top-2 right-2 px-1.5 py-0.5 text-xs font-medium rounded-full ${
            stock === 0 ? "bg-red-500 text-white" : lowStock ? "bg-amber-500 text-white" : "bg-green-500 text-white"
          }`}
        >
          {stock}
        </div>
      )}
    </button>
  )
}
