"use client"

import type React from "react"

import { useState } from "react"
import { X } from "lucide-react"

interface CashRegisterModalProps {
  isOpen: boolean
  type: "open" | "close"
  onClose: () => void
  onSubmit: (amount: number) => void
}

export default function CashRegisterModal({ isOpen, type, onClose, onSubmit }: CashRegisterModalProps) {
  const [amount, setAmount] = useState("")

  if (!isOpen) return null

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const numAmount = Number.parseFloat(amount)
    if (!isNaN(numAmount) && numAmount >= 0) {
      onSubmit(numAmount)
      setAmount("")
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-lg w-full max-w-md p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">{type === "open" ? "Abrir Caja" : "Cerrar Caja"}</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-1">
              {type === "open" ? "Monto Inicial" : "Monto Final"}
            </label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
              <input
                type="number"
                id="amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full pl-8 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                placeholder="0.00"
                step="0.01"
                min="0"
                required
              />
            </div>
          </div>

          <div className="flex justify-end space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
            >
              Cancelar
            </button>
            <button type="submit" className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">
              {type === "open" ? "Abrir Caja" : "Cerrar Caja"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
