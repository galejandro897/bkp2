"use client"

import { useState } from "react"
import { Fingerprint, Camera } from "lucide-react"
import { getBiometricService } from "@/lib/services/biometric-service"

interface BiometricAuthProps {
  onSuccess: (employeeId: string) => void
  onError: (error: string) => void
  onCancel: () => void
}

export default function BiometricAuth({ onSuccess, onError, onCancel }: BiometricAuthProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [method, setMethod] = useState<"fingerprint" | "facial" | null>(null)
  const [step, setStep] = useState<"select" | "capture" | "processing">("select")

  const handleMethodSelect = (selectedMethod: "fingerprint" | "facial") => {
    setMethod(selectedMethod)
    setStep("capture")
  }

  const handleCapture = async () => {
    if (!method) return

    setIsLoading(true)
    setStep("processing")

    try {
      const bioService = getBiometricService()

      let biometricTemplate = ""
      if (method === "fingerprint") {
        biometricTemplate = await bioService.captureFingerprint()
      } else {
        biometricTemplate = await bioService.captureFacialRecognition()
      }

      const employee = await bioService.authenticateWithBiometric(biometricTemplate)

      if (employee) {
        onSuccess(employee.id)
      } else {
        onError("No se pudo autenticar. Intente nuevamente.")
        setStep("select")
      }
    } catch (error) {
      onError("Error en la autenticación biométrica")
      setStep("select")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
      <h2 className="text-xl font-bold mb-4 text-center">Autenticación Biométrica</h2>

      {step === "select" && (
        <div className="space-y-4">
          <p className="text-center text-gray-600 mb-4">Seleccione un método de autenticación biométrica</p>

          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => handleMethodSelect("fingerprint")}
              className="flex flex-col items-center justify-center p-4 border rounded-lg hover:bg-gray-50"
            >
              <Fingerprint size={48} className="text-red-600 mb-2" />
              <span>Huella Digital</span>
            </button>

            <button
              onClick={() => handleMethodSelect("facial")}
              className="flex flex-col items-center justify-center p-4 border rounded-lg hover:bg-gray-50"
            >
              <Camera size={48} className="text-red-600 mb-2" />
              <span>Reconocimiento Facial</span>
            </button>
          </div>

          <button
            onClick={onCancel}
            className="w-full mt-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
          >
            Cancelar
          </button>
        </div>
      )}

      {step === "capture" && (
        <div className="space-y-4">
          <div className="flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-lg">
            {method === "fingerprint" ? (
              <>
                <Fingerprint size={64} className="text-red-600 mb-4" />
                <p className="text-center">Coloque su dedo en el lector de huellas</p>
              </>
            ) : (
              <>
                <Camera size={64} className="text-red-600 mb-4" />
                <p className="text-center">Mire a la cámara para reconocimiento facial</p>
              </>
            )}
          </div>

          <div className="flex space-x-2">
            <button
              onClick={() => setStep("select")}
              className="flex-1 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300"
            >
              Atrás
            </button>
            <button onClick={handleCapture} className="flex-1 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">
              Capturar
            </button>
          </div>
        </div>
      )}

      {step === "processing" && (
        <div className="flex flex-col items-center justify-center p-8">
          <div className="w-16 h-16 border-4 border-red-600 border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-center">
            {method === "fingerprint" ? "Procesando huella digital..." : "Procesando reconocimiento facial..."}
          </p>
        </div>
      )}
    </div>
  )
}
